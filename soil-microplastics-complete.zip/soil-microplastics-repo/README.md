# soil-microplastics

[![Python Tests](https://github.com/oliveira-et-al/soil-microplastics/actions/workflows/python-tests.yml/badge.svg)](https://github.com/oliveira-et-al/soil-microplastics/actions/workflows/python-tests.yml)
[![R Tests](https://github.com/oliveira-et-al/soil-microplastics/actions/workflows/r-tests.yml/badge.svg)](https://github.com/oliveira-et-al/soil-microplastics/actions/workflows/r-tests.yml)
[![Codecov](https://codecov.io/gh/oliveira-et-al/soil-microplastics/branch/main/graph/badge.svg)](https://codecov.io/gh/oliveira-et-al/soil-microplastics)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![License: CC BY 4.0](https://img.shields.io/badge/License-CC%20BY%204.0-lightgrey.svg)](https://creativecommons.org/licenses/by/4.0/)

## Dual-language software ecosystem for microplastic and additive impacts on soil organic carbon

This repository contains the official implementation of the analytical framework described in:

> Oliveira et al. (2026). *Agricultural Plastic Photodegradation: Soil and Carbon Impacts*. [Journal Name]

### Packages

- **Python**: `soil_microplastics` ([PyPI](https://pypi.org/project/soil-microplastics/))
- **R**: `soilMicroplastics` ([CRAN](https://cran.r-project.org/package=soilMicroplastics))

### Installation

**Python:**
```bash
pip install soil-microplastics
```

**R:**
```r
install.packages("soilMicroplastics")
# or development version:
devtools::install_github("oliveira-et-al/soil-microplastics")
```

### Quick Start

```python
from soil_microplastics import degradation_rate, half_life, hazard_score

k = degradation_rate(35, "PVC")
t_half = half_life(35, "PVC")
hs = hazard_score("PVC")
```

```r
library(soilMicroplastics)

k <- degradation_rate(35, "PVC")
t_half <- half_life(35, "PVC")
hs <- hazard_score("PVC")
```

### Repository Structure

```
soil-microplastics/
|-- src/python/          # Python package source
|-- src/r/               # R package source
|-- tests/               # Test suites (pytest + testthat)
|-- docs/                # Documentation
|-- notebooks/           # Jupyter + Rmd examples
|-- examples/            # Minimal working examples
|-- data/                # Built-in datasets
```

### License

- **Code**: MIT License
- **Data and Figures**: CC-BY-4.0

### Citation

```bibtex
@article{oliveira2026,
  title={Agricultural Plastic Photodegradation: Soil and Carbon Impacts},
  author={Oliveira, ...},
  journal={...},
  year={2026}
}
```

## R Package Installation

### From CRAN (recommended)
```r
install.packages("soilMicroplastics")
```

### From GitHub (development version)
```r
# install.packages("devtools")
devtools::install_github("oliveira-et-al/soil-microplastics", subdir = "src/r")
```

### R Quick Start
```r
library(soilMicroplastics)

# Degradation rate of PVC at 35°C
k <- degradation_rate(35, "PVC")
cat("k(35°C) =", format(k, digits = 2), "s^-1\n")

# Half-life
t_half <- half_life(35, "PVC")
cat("t_1/2 =", format(t_half, digits = 2), "seconds\n")

# Hazard score
hs <- hazard_score("PVC")
cat("Hazard Score:", hs$Hazard_Score, "(", hs$Risk_Class, ")\n")

# Plot degradation profile
p <- plot_degradation_profile("PVC")
print(p)
```
