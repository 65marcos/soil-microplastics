#' Additive Release Module
#'
#' Fickian diffusion, hazard scores, release kinetics.
#'
#' @name additives
#' @docType package
#' @keywords internal
"_PACKAGE"

# Additive hazard data from Oliveira et al. (2026)
ADDITIVE_DATA <- list(
  phthalates = list(
    compounds = c("DEHP", "DINP", "DIDP", "DnBP"),
    concentration_range = c(0.1, 23.2),
    units = "mg/kg"
  ),
  bisphenols = list(
    compounds = c("BPA", "BPS", "BPF"),
    concentration_range = c(0.05, 5.2),
    units = "mg/kg"
  ),
  heavy_metals = list(
    compounds = c("Pb", "Cd", "Sn"),
    concentration_range = c(4.1, 100),
    units = "mg/kg"
  ),
  flame_retardants = list(
    compounds = c("decaBDE", "HBCD", "TBBPA"),
    concentration_range = c(0.01, 2.1),
    units = "mg/kg"
  ),
  uv_stabilizers = list(
    compounds = c("UV-328", "UV-327", "HOBT"),
    concentration_range = c(0.03, 1.7),
    units = "mg/kg"
  )
)

#' Hazard Score
#'
#' Calculate hazard score and risk classification for a polymer.
#'
#' @param polymer Polymer name ("PVC", "PU", "PAN", "ABS", "PC").
#' @return List with Hazard_Score, Risk_Class, T_g, T_max.
#' @examples
#' hs <- hazard_score("PVC")
#' print(paste("Hazard Score:", hs$Hazard_Score, "(", hs$Risk_Class, ")"))
#' @export
hazard_score <- function(polymer) {
  if (!polymer %in% names(POLYMER_DATA)) {
    stop("Unknown polymer: ", polymer)
  }

  hs <- POLYMER_DATA[[polymer]]$HS

  # Risk classification
  if (hs >= 10) {
    risk_class <- "High Hazard"
  } else if (hs >= 5) {
    risk_class <- "Moderate Hazard"
  } else if (hs >= 1) {
    risk_class <- "Low Hazard"
  } else {
    risk_class <- "Negligible"
  }

  list(
    Hazard_Score = hs,
    Risk_Class = risk_class,
    T_g = POLYMER_DATA[[polymer]]$Tg,
    T_max = POLYMER_DATA[[polymer]]$T_max
  )
}

#' Diffusion Coefficient
#'
#' Calculate Fickian diffusion coefficient for additive release.
#'
#' @param T Temperature in Celsius.
#' @param additive Additive class ("phthalates", "bisphenols", etc.).
#' @param polymer Polymer matrix.
#' @return Diffusion coefficient in m^2/s.
#' @examples
#' D <- diffusion_coefficient(35, "phthalates", "PVC")
#' @export
diffusion_coefficient <- function(T, additive, polymer) {
  D0 <- 1e-12  # Reference diffusion coefficient
  Ea_diff <- 50  # Activation energy for diffusion (kJ/mol)
  R <- 8.314

  T_kelvin <- T + 273.15
  D0 * exp(-Ea_diff * 1000 / R * (1/T_kelvin - 1/298.15))
}

#' Release Kinetics
#'
#' Calculate additive release fraction using Fickian diffusion model.
#'
#' @param t Time in seconds.
#' @param T Temperature in Celsius.
#' @param additive Additive class.
#' @param polymer Polymer matrix.
#' @param thickness Film thickness in meters (default: 1 mm).
#' @return Released fraction (0-1).
#' @examples
#' released <- release_kinetics(3600, 35, "phthalates", "PVC")
#' @export
release_kinetics <- function(t, T, additive, polymer, thickness = 1e-3) {
  D <- diffusion_coefficient(T, additive, polymer)

  # Simplified 1D diffusion solution
  if (D * t / (thickness^2) < 0.01) {
    2 * sqrt(D * t / (pi * thickness^2))
  } else {
    # Approximate solution for longer times
    1 - exp(-pi^2 * D * t / (4 * thickness^2))
  }
}
