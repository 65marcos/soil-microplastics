#' Data Module
#'
#' Built-in datasets from Oliveira et al. (2026).
#'
#' @name data
#' @docType package
#' @keywords internal
"_PACKAGE"

#' Load Polymer Data
#'
#' Load built-in polymer properties dataset.
#'
#' @return Tibble with polymer properties.
#' @examples
#' polymers <- load_polymer_data()
#' head(polymers)
#' @export
load_polymer_data <- function() {
  data <- purrr::map_dfr(names(POLYMER_DATA), function(polymer) {
    tibble::tibble(
      Polymer = polymer,
      Tg = POLYMER_DATA[[polymer]]$Tg,
      T_max = POLYMER_DATA[[polymer]]$T_max,
      Ea = POLYMER_DATA[[polymer]]$Ea,
      Hazard_Score = POLYMER_DATA[[polymer]]$HS
    )
  })

  data
}

#' Load Soil Data
#'
#' Load built-in soil scenario dataset.
#'
#' @return Tibble with soil scenarios.
#' @examples
#' soils <- load_soil_data()
#' head(soils)
#' @export
load_soil_data <- function() {
  tibble::tibble(
    Scenario = c("Typical soil", "Warm soil", "Hot soil", "Arid", "Tropical"),
    Temperature_C = c(25, 35, 45, 40, 30),
    Clay_fraction = c(0.25, 0.20, 0.15, 0.10, 0.30),
    pH = c(6.5, 6.8, 7.2, 8.0, 5.5),
    Moisture = c(0.30, 0.25, 0.15, 0.05, 0.40)
  )
}

#' Load Additive Data
#'
#' Load built-in additive dataset.
#'
#' @return Tibble with additive properties.
#' @examples
#' additives <- load_additive_data()
#' head(additives)
#' @export
load_additive_data <- function() {
  purrr::map_dfr(names(ADDITIVE_DATA), function(additive) {
    info <- ADDITIVE_DATA[[additive]]
    tibble::tibble(
      Additive_Class = additive,
      Compounds = paste(info$compounds, collapse = ", "),
      Min_Concentration = info$concentration_range[1],
      Max_Concentration = info$concentration_range[2],
      Units = info$units
    )
  })
}
