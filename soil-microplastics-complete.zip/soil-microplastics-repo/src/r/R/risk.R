#' Risk Assessment Module
#'
#' Risk matrices, Pareto analysis, sensitivity analysis.
#'
#' @name risk
#' @docType package
#' @keywords internal
"_PACKAGE"

#' Risk Matrix
#'
#' Generate risk matrix (hazard x degradability) for polymer-temperature combinations.
#'
#' @param temperatures Vector of temperatures in Celsius.
#' @param polymers Vector of polymer names.
#' @return Tibble with risk metrics.
#' @examples
#' df <- risk_matrix(c(25, 35, 45), c("PVC", "PU", "PC"))
#' head(df)
#' @export
risk_matrix <- function(temperatures, polymers) {
  data <- purrr::map_dfr(polymers, function(polymer) {
    hs <- hazard_score(polymer)
    purrr::map_dfr(temperatures, function(T) {
      k <- degradation_rate(T, polymer)
      k_ref <- degradation_rate(25, "PVC")
      rel_rate <- if (k_ref > 0) k / k_ref else 0

      tibble::tibble(
        Polymer = polymer,
        Temperature_C = T,
        Hazard_Score = hs$Hazard_Score,
        Risk_Class = hs$Risk_Class,
        Degradation_Rate = k,
        Relative_Rate = rel_rate,
        Combined_Risk = hs$Hazard_Score * rel_rate
      )
    })
  })

  data
}

#' Pareto Analysis
#'
#' Identify Pareto-optimal polymers (minimize hazard, maximize degradability).
#'
#' @param polymers Vector of polymer names.
#' @param temperature Temperature for degradability assessment (default: 35).
#' @return Tibble with Pareto frontier and dominance ranking.
#' @examples
#' pareto <- pareto_analysis(c("PVC", "PU", "PAN", "ABS", "PC"))
#' print(pareto)
#' @export
pareto_analysis <- function(polymers, temperature = 35) {
  data <- purrr::map_dfr(polymers, function(polymer) {
    hs <- hazard_score(polymer)
    k <- degradation_rate(temperature, polymer)

    tibble::tibble(
      Polymer = polymer,
      Hazard_Score = hs$Hazard_Score,
      Degradability = k,
      Risk_Class = hs$Risk_Class
    )
  })

  # Identify Pareto frontier
  data$Pareto_Optimal <- TRUE
  for (i in seq_len(nrow(data))) {
    for (j in seq_len(nrow(data))) {
      if (i != j) {
        if (data$Hazard_Score[j] <= data$Hazard_Score[i] && 
            data$Degradability[j] >= data$Degradability[i] &&
            (data$Hazard_Score[j] < data$Hazard_Score[i] || 
             data$Degradability[j] > data$Degradability[i])) {
          data$Pareto_Optimal[i] <- FALSE
          break
        }
      }
    }
  }

  data
}

#' Sensitivity Analysis
#'
#' Perform sensitivity analysis on model parameters.
#'
#' @param polymer Polymer name.
#' @param param Parameter to vary ("Ea", "T_max", "T_g").
#' @param range_factor Fractional variation range (default: 0.2).
#' @param n_points Number of evaluation points (default: 50).
#' @return Tibble with sensitivity results.
#' @examples
#' sens <- sensitivity_analysis("PVC", "Ea")
#' head(sens)
#' @export
sensitivity_analysis <- function(polymer, param, range_factor = 0.2, n_points = 50) {
  base_value <- POLYMER_DATA[[polymer]][[param]]
  variations <- seq(base_value * (1 - range_factor), 
                   base_value * (1 + range_factor), 
                   length.out = n_points)

  results <- purrr::map_dfr(variations, function(val) {
    # Temporarily modify parameter
    original <- POLYMER_DATA[[polymer]][[param]]
    POLYMER_DATA[[polymer]][[param]] <<- val

    k <- degradation_rate(35, polymer)

    # Restore original
    POLYMER_DATA[[polymer]][[param]] <<- original

    tibble::tibble(
      Parameter = param,
      Value = val,
      Degradation_Rate = k,
      Relative_Change = (k - degradation_rate(35, polymer)) / k
    )
  })

  results
}
