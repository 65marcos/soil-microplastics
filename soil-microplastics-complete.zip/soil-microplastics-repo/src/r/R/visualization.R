#' Visualization Module
#'
#' Publication-quality plots using ggplot2.
#'
#' @name visualization
#' @docType package
#' @keywords internal
"_PACKAGE"

#' Plot Degradation Profile
#'
#' Plot Gaussian degradation profile for a polymer (Figure S6A equivalent).
#'
#' @param polymer Polymer name.
#' @param T_range Temperature range (min, max) in Celsius (default: c(20, 600)).
#' @param n_points Number of points (default: 1000).
#' @return ggplot object.
#' @examples
#' p <- plot_degradation_profile("PVC")
#' print(p)
#' @export
plot_degradation_profile <- function(polymer, T_range = c(20, 600), n_points = 1000) {
  T_vals <- seq(T_range[1], T_range[2], length.out = n_points)
  k_vals <- sapply(T_vals, function(T) degradation_rate(T, polymer, method = "gaussian"))

  df <- tibble::tibble(
    Temperature = T_vals,
    Degradation_Rate = k_vals
  )

  ggplot2::ggplot(df, ggplot2::aes(x = Temperature, y = Degradation_Rate)) +
    ggplot2::geom_line(linewidth = 1.2, color = "steelblue") +
    ggplot2::geom_vline(xintercept = POLYMER_DATA[[polymer]]$Tg, 
                       linetype = "dashed", color = "gray50", alpha = 0.7) +
    ggplot2::labs(
      title = paste("Degradation Profile:", polymer),
      subtitle = paste("Tg =", POLYMER_DATA[[polymer]]$Tg, "°C"),
      x = "Temperature (°C)",
      y = "Normalized Degradation Rate"
    ) +
    ggplot2::theme_minimal() +
    ggplot2::theme(
      plot.title = ggplot2::element_text(face = "bold", size = 14),
      axis.title = ggplot2::element_text(size = 12)
    )
}

#' Plot Risk Matrix
#'
#' Plot risk matrix (hazard vs. degradability) (Figure S7B equivalent).
#'
#' @param df Risk matrix from risk_matrix().
#' @return ggplot object.
#' @examples
#' df <- risk_matrix(c(25, 35, 45), c("PVC", "PU", "PC"))
#' p <- plot_risk_matrix(df)
#' print(p)
#' @export
plot_risk_matrix <- function(df) {
  ggplot2::ggplot(df, ggplot2::aes(x = Relative_Rate, y = Hazard_Score, 
                                    color = Polymer, shape = Risk_Class)) +
    ggplot2::geom_point(size = 4, alpha = 0.7) +
    ggplot2::scale_x_log10() +
    ggplot2::scale_y_log10() +
    ggplot2::geom_hline(yintercept = 5, linetype = "dashed", color = "red", alpha = 0.3) +
    ggplot2::geom_vline(xintercept = 1, linetype = "dashed", color = "red", alpha = 0.3) +
    ggplot2::labs(
      title = "Risk Matrix: Hazard vs. Degradability",
      x = "Environmental Degradability (relative rate, log scale)",
      y = "Hazard Score (log scale)"
    ) +
    ggplot2::theme_minimal() +
    ggplot2::theme(
      plot.title = ggplot2::element_text(face = "bold", size = 14),
      legend.position = "right"
    )
}

#' Plot Convergence Analysis
#'
#' Plot convergence analysis (Figure S9-2 equivalent).
#'
#' @param results Results from numerical_integration_methods().
#' @return ggplot object.
#' @examples
#' results <- numerical_integration_methods(c(20, 600), "PVC", c(10, 20, 50, 100))
#' p <- plot_convergence_analysis(results)
#' print(p)
#' @export
plot_convergence_analysis <- function(results) {
  n_vals <- as.numeric(names(results$methods))

  plot_data <- purrr::map_dfr(names(results$methods), function(n) {
    methods <- results$methods[[n]]
    tibble::tibble(
      n = as.numeric(n),
      Trapezoidal = methods$trapezoidal,
      Simpson = methods$simpson,
      Gauss_Legendre = methods$gauss_legendre
    )
  })

  plot_data_long <- tidyr::pivot_longer(
    plot_data, 
    cols = c("Trapezoidal", "Simpson", "Gauss_Legendre"),
    names_to = "Method",
    values_to = "Error"
  )

  ggplot2::ggplot(plot_data_long, ggplot2::aes(x = n, y = Error, color = Method)) +
    ggplot2::geom_line(linewidth = 1) +
    ggplot2::geom_point(size = 3) +
    ggplot2::scale_x_log10() +
    ggplot2::scale_y_log10() +
    ggplot2::labs(
      title = "Convergence Analysis",
      subtitle = "Relative Error vs. Number of Intervals/Nodes",
      x = "n (log scale)",
      y = "Relative Error (% , log scale)"
    ) +
    ggplot2::theme_minimal() +
    ggplot2::theme(
      plot.title = ggplot2::element_text(face = "bold", size = 14)
    )
}

#' Plot Cumulative Degradation
#'
#' Plot cumulative degradation curve (Figure S6B equivalent).
#'
#' @param polymer Polymer name.
#' @param T_range Temperature range (default: c(20, 600)).
#' @return ggplot object.
#' @examples
#' p <- plot_cumulative_degradation("PVC")
#' print(p)
#' @export
plot_cumulative_degradation <- function(polymer, T_range = c(20, 600)) {
  T_vals <- seq(T_range[1], T_range[2], length.out = 1000)

  # Calculate cumulative using cumulative_degradation at each point
  cum_vals <- sapply(T_vals, function(T) {
    cumulative_degradation(c(T_range[1], T), polymer, n_points = 100)
  })

  # Normalize to percentage
  total <- cumulative_degradation(T_range, polymer)
  cum_pct <- cum_vals / total * 100

  df <- tibble::tibble(
    Temperature = T_vals,
    Cumulative = cum_pct
  )

  ggplot2::ggplot(df, ggplot2::aes(x = Temperature, y = Cumulative)) +
    ggplot2::geom_line(linewidth = 1.2, color = "darkgreen") +
    ggplot2::geom_hline(yintercept = 50, linetype = "dashed", color = "red", alpha = 0.5) +
    ggplot2::labs(
      title = paste("Cumulative Degradation:", polymer),
      x = "Temperature (°C)",
      y = "Cumulative Degradation (%)"
    ) +
    ggplot2::theme_minimal() +
    ggplot2::theme(
      plot.title = ggplot2::element_text(face = "bold", size = 14)
    )
}
