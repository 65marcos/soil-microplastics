test_that("degradation_rate works correctly", {
  k <- degradation_rate(35, "PVC")
  expect_gt(k, 0)
  expect_lt(k, 1e-20)
})

test_that("half_life is positive and large", {
  t_half <- half_life(35, "PVC")
  expect_gt(t_half, 0)
  expect_gt(t_half, 1e15)
})

test_that("cumulative_degradation is positive", {
  result <- cumulative_degradation(c(20, 600), "PVC")
  expect_gt(result, 0)
})

test_that("numerical integration converges", {
  results <- numerical_integration_methods(c(20, 600), "PVC", c(10, 20, 50, 100))
  expect_true("reference" %in% names(results))
  expect_equal(length(results$methods), 4)
})

test_that("polymer data is complete", {
  expect_true("PVC" %in% names(POLYMER_DATA))
  expect_true("PU" %in% names(POLYMER_DATA))
  expect_true("PC" %in% names(POLYMER_DATA))

  for (polymer in names(POLYMER_DATA)) {
    expect_true(!is.null(POLYMER_DATA[[polymer]]$Tg))
    expect_true(!is.null(POLYMER_DATA[[polymer]]$T_max))
    expect_true(!is.null(POLYMER_DATA[[polymer]]$Ea))
    expect_true(!is.null(POLYMER_DATA[[polymer]]$HS))
  }
})
