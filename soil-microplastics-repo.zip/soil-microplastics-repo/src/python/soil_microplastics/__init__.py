"""
soil_microplastics: Microplastic and additive impacts on soil organic carbon

Python implementation of the analytical framework from Oliveira et al. (2026).
"""

__version__ = "1.0.0"
__author__ = "Oliveira et al."

from .degradation import degradation_rate, half_life, cumulative_degradation
from .additives import hazard_score, release_kinetics, diffusion_coefficient
from .risk import risk_matrix, pareto_analysis, sensitivity_analysis
from .visualization import plot_degradation_profile, plot_risk_matrix
from .data import load_polymer_data, load_soil_data

__all__ = [
    "degradation_rate",
    "half_life",
    "cumulative_degradation",
    "hazard_score",
    "release_kinetics",
    "diffusion_coefficient",
    "risk_matrix",
    "pareto_analysis",
    "sensitivity_analysis",
    "plot_degradation_profile",
    "plot_risk_matrix",
    "load_polymer_data",
    "load_soil_data",
]
