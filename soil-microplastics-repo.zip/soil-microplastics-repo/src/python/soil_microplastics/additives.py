"""
Additive release module: Fickian diffusion, hazard scores, release kinetics
"""

import numpy as np
from typing import Dict, List

# Additive hazard data from Oliveira et al. (2026)
ADDITIVE_DATA = {
    "phthalates": {"compounds": ["DEHP", "DINP", "DIDP", "DnBP"], 
                   "concentration_range": (0.1, 23.2), "units": "mg/kg"},
    "bisphenols": {"compounds": ["BPA", "BPS", "BPF"], 
                   "concentration_range": (0.05, 5.2), "units": "mg/kg"},
    "heavy_metals": {"compounds": ["Pb", "Cd", "Sn"], 
                     "concentration_range": (4.1, 100), "units": "mg/kg"},
    "flame_retardants": {"compounds": ["decaBDE", "HBCD", "TBBPA"], 
                         "concentration_range": (0.01, 2.1), "units": "mg/kg"},
    "uv_stabilizers": {"compounds": ["UV-328", "UV-327", "HOBT"], 
                       "concentration_range": (0.03, 1.7), "units": "mg/kg"},
}


def hazard_score(polymer: str) -> Dict:
    """
    Calculate hazard score and risk classification for a polymer.

    Parameters
    ----------
    polymer : str
        Polymer name ("PVC", "PU", "PAN", "ABS", "PC")

    Returns
    -------
    dict
        {"Hazard_Score": float, "Risk_Class": str, "T_g": float, "T_max": float}

    Examples
    --------
    >>> hs = hazard_score("PVC")
    >>> print(f"Hazard Score: {hs['Hazard_Score']} ({hs['Risk_Class']})")
    Hazard Score: 10.551 (High Hazard)
    """
    from .degradation import POLYMER_DATA

    if polymer not in POLYMER_DATA:
        raise ValueError(f"Unknown polymer: {polymer}")

    hs = POLYMER_DATA[polymer]["HS"]

    # Risk classification based on hazard score
    if hs >= 10:
        risk_class = "High Hazard"
    elif hs >= 5:
        risk_class = "Moderate Hazard"
    elif hs >= 1:
        risk_class = "Low Hazard"
    else:
        risk_class = "Negligible"

    return {
        "Hazard_Score": hs,
        "Risk_Class": risk_class,
        "T_g": POLYMER_DATA[polymer]["Tg"],
        "T_max": POLYMER_DATA[polymer]["T_max"],
    }


def diffusion_coefficient(T: float, additive: str, polymer: str) -> float:
    """
    Calculate Fickian diffusion coefficient for additive release.

    Parameters
    ----------
    T : float
        Temperature in Celsius
    additive : str
        Additive class ("phthalates", "bisphenols", etc.)
    polymer : str
        Polymer matrix

    Returns
    -------
    float
        Diffusion coefficient in m^2/s
    """
    # Simplified Arrhenius-type diffusion model
    D0 = 1e-12  # Reference diffusion coefficient
    Ea_diff = 50  # Activation energy for diffusion (kJ/mol)
    R = 8.314

    T_kelvin = T + 273.15
    return D0 * np.exp(-Ea_diff * 1000 / R * (1/T_kelvin - 1/298.15))


def release_kinetics(t: float, T: float, additive: str, polymer: str, 
                   thickness: float = 1e-3) -> float:
    """
    Calculate additive release fraction using Fickian diffusion model.

    Parameters
    ----------
    t : float
        Time in seconds
    T : float
        Temperature in Celsius
    additive : str
        Additive class
    polymer : str
        Polymer matrix
    thickness : float
        Film thickness in meters (default: 1 mm)

    Returns
    -------
    float
        Released fraction (0-1)
    """
    D = diffusion_coefficient(T, additive, polymer)

    # Simplified 1D diffusion solution
    # Mt/Minf ≈ 2 * sqrt(D*t / (pi * L^2))
    if D * t / (thickness ** 2) < 0.01:
        return 2 * np.sqrt(D * t / (np.pi * thickness ** 2))
    else:
        # Approximate solution for longer times
        return 1 - np.exp(-np.pi ** 2 * D * t / (4 * thickness ** 2))
