"""
Data module: Built-in datasets from Oliveira et al. (2026)
"""

import pandas as pd
import numpy as np
from typing import Dict


def load_polymer_data() -> pd.DataFrame:
    """
    Load built-in polymer properties dataset.

    Returns
    -------
    pandas.DataFrame
        Polymer properties (Tg, T_max, Ea, HS)
    """
    from .degradation import POLYMER_DATA

    return pd.DataFrame.from_dict(POLYMER_DATA, orient='index')


def load_soil_data() -> pd.DataFrame:
    """
    Load built-in soil scenario dataset.

    Returns
    -------
    pandas.DataFrame
        Soil temperature scenarios and properties
    """
    data = {
        "Scenario": ["Typical soil", "Warm soil", "Hot soil", "Arid", "Tropical"],
        "Temperature_C": [25, 35, 45, 40, 30],
        "Clay_fraction": [0.25, 0.20, 0.15, 0.10, 0.30],
        "pH": [6.5, 6.8, 7.2, 8.0, 5.5],
        "Moisture": [0.30, 0.25, 0.15, 0.05, 0.40],
    }
    return pd.DataFrame(data)


def load_additive_data() -> pd.DataFrame:
    """
    Load built-in additive dataset.

    Returns
    -------
    pandas.DataFrame
        Additive properties and concentration ranges
    """
    from .additives import ADDITIVE_DATA

    rows = []
    for additive, info in ADDITIVE_DATA.items():
        rows.append({
            "Additive_Class": additive,
            "Compounds": ", ".join(info["compounds"]),
            "Min_Concentration": info["concentration_range"][0],
            "Max_Concentration": info["concentration_range"][1],
            "Units": info["units"],
        })

    return pd.DataFrame(rows)
