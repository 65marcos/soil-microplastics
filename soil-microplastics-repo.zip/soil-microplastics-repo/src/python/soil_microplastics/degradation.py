"""
Degradation kinetics module: Gaussian models, Arrhenius kinetics, numerical integration
"""

import numpy as np
from scipy import integrate, special
from typing import Dict, Union, Optional

# Built-in polymer parameters from Oliveira et al. (2026)
POLYMER_DATA = {
    "PVC": {"Tg": 82.5, "T_max": 300, "Ea": 170, "HS": 10.551},
    "PU": {"Tg": 25, "T_max": 350, "Ea": 150, "HS": 7.384},
    "PAN": {"Tg": 85, "T_max": 380, "Ea": 160, "HS": 10.599},
    "ABS": {"Tg": 105, "T_max": 420, "Ea": 180, "HS": 130},
    "PC": {"Tg": 150, "T_max": 450, "Ea": 200, "HS": 85},
}


def arrhenius_factor(T: float, Ea: float, T_ref: float = 298.15) -> float:
    """
    Calculate Arrhenius temperature dependency factor.

    Parameters
    ----------
    T : float
        Temperature in Celsius
    Ea : float
        Activation energy in kJ/mol
    T_ref : float
        Reference temperature in Kelvin (default: 298.15)

    Returns
    -------
    float
        Arrhenius factor (dimensionless)
    """
    R = 8.314  # J/(mol·K)
    T_kelvin = T + 273.15
    return np.exp(-Ea * 1000 / R * (1/T_kelvin - 1/T_ref))


def gaussian_profile(T: float, T_max: float, sigma: float = 50) -> float:
    """
    Gaussian degradation profile centered at T_max.

    Parameters
    ----------
    T : float
        Temperature in Celsius
    T_max : float
        Peak degradation temperature
    sigma : float
        Standard deviation of Gaussian (default: 50)

    Returns
    -------
    float
        Normalized degradation rate (0-1)
    """
    return np.exp(-0.5 * ((T - T_max) / sigma) ** 2)


def degradation_rate(T: float, polymer: str, method: str = "combined") -> float:
    """
    Calculate degradation rate k(T) for a given polymer at temperature T.

    Parameters
    ----------
    T : float
        Temperature in Celsius
    polymer : str
        Polymer name ("PVC", "PU", "PAN", "ABS", "PC")
    method : str
        Calculation method: "arrhenius", "gaussian", or "combined" (default)

    Returns
    -------
    float
        Degradation rate in s^-1

    Examples
    --------
    >>> k = degradation_rate(35, "PVC")
    >>> print(f"k(35°C) = {k:.2e} s^-1")
    k(35°C) = 3.98e-26 s^-1
    """
    if polymer not in POLYMER_DATA:
        raise ValueError(f"Unknown polymer: {polymer}. Available: {list(POLYMER_DATA.keys())}")

    params = POLYMER_DATA[polymer]

    if method == "arrhenius":
        return arrhenius_factor(T, params["Ea"])
    elif method == "gaussian":
        return gaussian_profile(T, params["T_max"])
    elif method == "combined":
        k_ref = 1e10  # Reference rate constant at T_max
        return k_ref * arrhenius_factor(T, params["Ea"]) * gaussian_profile(T, params["T_max"])
    else:
        raise ValueError(f"Unknown method: {method}")


def half_life(T: float, polymer: str) -> float:
    """
    Calculate half-life t_1/2 = ln(2)/k(T).

    Parameters
    ----------
    T : float
        Temperature in Celsius
    polymer : str
        Polymer name

    Returns
    -------
    float
        Half-life in seconds
    """
    k = degradation_rate(T, polymer)
    if k <= 0:
        return np.inf
    return np.log(2) / k


def cumulative_degradation(T_range: tuple, polymer: str, n_points: int = 1000) -> float:
    """
    Numerical integration of degradation rate over temperature range.

    Parameters
    ----------
    T_range : tuple
        (T_min, T_max) in Celsius
    polymer : str
        Polymer name
    n_points : int
        Number of integration points

    Returns
    -------
    float
        Cumulative degradation (fraction)
    """
    T_min, T_max = T_range
    T_vals = np.linspace(T_min, T_max, n_points)
    k_vals = [degradation_rate(T, polymer) for T in T_vals]

    # Simpson's rule integration
    return integrate.simpson(k_vals, T_vals)


def numerical_integration_methods(T_range: tuple, polymer: str, n_list: list) -> Dict:
    """
    Compare numerical integration methods (Table S1).

    Parameters
    ----------
    T_range : tuple
        (T_min, T_max) in Celsius
    polymer : str
        Polymer name
    n_list : list
        List of n values to test

    Returns
    -------
    dict
        Results for each method
    """
    from scipy.integrate import quad

    # Reference value using scipy quad
    def integrand(T):
        return degradation_rate(T, polymer)

    ref, _ = quad(integrand, T_range[0], T_range[1])

    results = {"reference": ref, "methods": {}}

    for n in n_list:
        T_vals = np.linspace(T_range[0], T_range[1], n)
        k_vals = np.array([degradation_rate(T, polymer) for T in T_vals])
        h = (T_range[1] - T_range[0]) / (n - 1)

        # Trapezoidal
        trap = np.trapezoid(k_vals, T_vals)

        # Simpson
        simp = integrate.simpson(k_vals, T_vals)

        # Gauss-Legendre (simplified)
        x, w = special.roots_legendre(n)
        a, b = T_range
        T_gl = 0.5 * (b - a) * x + 0.5 * (b + a)
        k_gl = np.array([degradation_rate(T, polymer) for T in T_gl])
        gauss = 0.5 * (b - a) * np.sum(w * k_gl)

        results["methods"][n] = {
            "trapezoidal": abs(trap - ref) / ref * 100,
            "simpson": abs(simp - ref) / ref * 100,
            "gauss_legendre": abs(gauss - ref) / ref * 100,
        }

    return results
