"""
Risk assessment module: Risk matrices, Pareto analysis, sensitivity analysis
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple
from .degradation import POLYMER_DATA, degradation_rate
from .additives import hazard_score


def risk_matrix(temperatures: List[float], polymers: List[str]) -> pd.DataFrame:
    """
    Generate risk matrix (hazard × degradability) for polymer-temperature combinations.

    Parameters
    ----------
    temperatures : list
        List of temperatures in Celsius
    polymers : list
        List of polymer names

    Returns
    -------
    pandas.DataFrame
        Risk matrix with hazard scores and relative degradation rates
    """
    data = []

    for polymer in polymers:
        hs = hazard_score(polymer)
        for T in temperatures:
            k = degradation_rate(T, polymer)
            # Relative rate normalized to PVC at 25°C
            k_ref = degradation_rate(25, "PVC")
            rel_rate = k / k_ref if k_ref > 0 else 0

            data.append({
                "Polymer": polymer,
                "Temperature_C": T,
                "Hazard_Score": hs["Hazard_Score"],
                "Risk_Class": hs["Risk_Class"],
                "Degradation_Rate": k,
                "Relative_Rate": rel_rate,
                "Combined_Risk": hs["Hazard_Score"] * rel_rate,
            })

    return pd.DataFrame(data)


def pareto_analysis(polymers: List[str], temperature: float = 35) -> pd.DataFrame:
    """
    Identify Pareto-optimal polymers (minimize hazard, maximize degradability).

    Parameters
    ----------
    polymers : list
        List of polymer names
    temperature : float
        Temperature for degradability assessment (default: 35°C)

    Returns
    -------
    pandas.DataFrame
        Pareto frontier with dominance ranking
    """
    data = []

    for polymer in polymers:
        hs = hazard_score(polymer)
        k = degradation_rate(temperature, polymer)

        data.append({
            "Polymer": polymer,
            "Hazard_Score": hs["Hazard_Score"],
            "Degradability": k,
            "Risk_Class": hs["Risk_Class"],
        })

    df = pd.DataFrame(data)

    # Identify Pareto frontier (minimize hazard, maximize degradability)
    df["Pareto_Optimal"] = True
    for i, row_i in df.iterrows():
        for j, row_j in df.iterrows():
            if i != j:
                if (row_j["Hazard_Score"] <= row_i["Hazard_Score"] and 
                    row_j["Degradability"] >= row_i["Degradability"] and
                    (row_j["Hazard_Score"] < row_i["Hazard_Score"] or 
                     row_j["Degradability"] > row_i["Degradability"])):
                    df.at[i, "Pareto_Optimal"] = False
                    break

    return df


def sensitivity_analysis(polymer: str, param: str, 
                         range_factor: float = 0.2, n_points: int = 50) -> pd.DataFrame:
    """
    Perform sensitivity analysis on model parameters.

    Parameters
    ----------
    polymer : str
        Polymer name
    param : str
        Parameter to vary ("Ea", "T_max", "T_g")
    range_factor : float
        Fractional variation range (default: ±20%)
    n_points : int
        Number of evaluation points

    Returns
    -------
    pandas.DataFrame
        Sensitivity results
    """
    from .degradation import POLYMER_DATA

    base_value = POLYMER_DATA[polymer][param]
    variations = np.linspace(base_value * (1 - range_factor), 
                            base_value * (1 + range_factor), n_points)

    results = []
    for val in variations:
        # Temporarily modify parameter
        original = POLYMER_DATA[polymer][param]
        POLYMER_DATA[polymer][param] = val

        k = degradation_rate(35, polymer)

        results.append({
            "Parameter": param,
            "Value": val,
            "Degradation_Rate": k,
            "Relative_Change": (k - degradation_rate(35, polymer, method="combined")) / k if k > 0 else 0,
        })

        POLYMER_DATA[polymer][param] = original

    return pd.DataFrame(results)
