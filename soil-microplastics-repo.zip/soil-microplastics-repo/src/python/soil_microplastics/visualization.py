"""
Visualization module: Publication-quality plots for all figures
"""

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.patches import Rectangle
from typing import Dict, List, Optional

# Set publication style
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 10
plt.rcParams['axes.labelsize'] = 11
plt.rcParams['axes.titlesize'] = 12
plt.rcParams['figure.dpi'] = 300


def plot_degradation_profile(polymer: str, T_range: tuple = (20, 600), 
                            n_points: int = 1000, ax=None):
    """
    Plot Gaussian degradation profile for a polymer (Figure S6A).

    Parameters
    ----------
    polymer : str
        Polymer name
    T_range : tuple
        Temperature range (min, max) in Celsius
    n_points : int
        Number of points
    ax : matplotlib.axes
        Optional axes object
    """
    from .degradation import degradation_rate, POLYMER_DATA

    if ax is None:
        fig, ax = plt.subplots(figsize=(8, 5))

    T_vals = np.linspace(T_range[0], T_range[1], n_points)
    k_vals = [degradation_rate(T, polymer, method="gaussian") for T in T_vals]

    ax.plot(T_vals, k_vals, linewidth=2, label=f"{polymer} (Tg={POLYMER_DATA[polymer]['Tg']}°C)")
    ax.axvline(POLYMER_DATA[polymer]["Tg"], color='gray', linestyle='--', alpha=0.5)
    ax.set_xlabel("Temperature (°C)")
    ax.set_ylabel("Normalized Degradation Rate")
    ax.set_title(f"Degradation Profile: {polymer}")
    ax.legend()
    ax.grid(True, alpha=0.3)

    return ax


def plot_risk_matrix(df, ax=None):
    """
    Plot risk matrix (hazard vs. degradability) (Figure S7B).

    Parameters
    ----------
    df : pandas.DataFrame
        Risk matrix from risk_matrix()
    ax : matplotlib.axes
        Optional axes object
    """
    if ax is None:
        fig, ax = plt.subplots(figsize=(8, 6))

    polymers = df["Polymer"].unique()
    colors = plt.cm.tab10(np.linspace(0, 1, len(polymers)))

    for i, polymer in enumerate(polymers):
        subset = df[df["Polymer"] == polymer]
        ax.scatter(subset["Relative_Rate"], subset["Hazard_Score"], 
                  label=polymer, s=100, color=colors[i], alpha=0.7, edgecolors='black')

    ax.set_xscale('log')
    ax.set_yscale('log')
    ax.set_xlabel("Environmental Degradability (relative rate)")
    ax.set_ylabel("Hazard Score")
    ax.set_title("Risk Matrix: Hazard vs. Degradability")
    ax.legend()
    ax.grid(True, alpha=0.3, which='both')

    # Add quadrant lines
    ax.axhline(y=5, color='red', linestyle='--', alpha=0.3)
    ax.axvline(x=1, color='red', linestyle='--', alpha=0.3)

    return ax


def plot_convergence_analysis(results: Dict, ax=None):
    """
    Plot convergence analysis (Figure S9-2).

    Parameters
    ----------
    results : dict
        Results from numerical_integration_methods()
    ax : matplotlib.axes
        Optional axes object
    """
    if ax is None:
        fig, ax = plt.subplots(figsize=(8, 6))

    n_vals = sorted(results["methods"].keys())

    for method in ["trapezoidal", "simpson", "gauss_legendre"]:
        errors = [results["methods"][n][method] for n in n_vals]
        ax.loglog(n_vals, errors, marker='o', label=method.replace('_', ' ').title())

    ax.set_xlabel("Number of intervals/nodes (n)")
    ax.set_ylabel("Relative Error (%)")
    ax.set_title("Convergence Analysis")
    ax.legend()
    ax.grid(True, alpha=0.3, which='both')

    return ax
