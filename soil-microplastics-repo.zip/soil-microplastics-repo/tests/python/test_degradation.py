"""
Tests for degradation module
"""

import pytest
import numpy as np
from soil_microplastics.degradation import (
    degradation_rate, half_life, cumulative_degradation,
    numerical_integration_methods, POLYMER_DATA
)


def test_degradation_rate_pvc():
    """Test degradation rate of PVC at 35°C"""
    k = degradation_rate(35, "PVC")
    assert k > 0
    assert k < 1e-20  # Very slow at 35°C


def test_half_life_pvc():
    """Test half-life calculation"""
    t_half = half_life(35, "PVC")
    assert t_half > 0
    assert t_half > 1e15  # Very long half-life


def test_cumulative_degradation():
    """Test numerical integration"""
    result = cumulative_degradation((20, 600), "PVC")
    assert result > 0


def test_numerical_integration_convergence():
    """Test convergence of integration methods"""
    n_list = [10, 20, 50, 100]
    results = numerical_integration_methods((20, 600), "PVC", n_list)

    assert "reference" in results
    assert len(results["methods"]) == len(n_list)

    # Check that error decreases with increasing n
    for method in ["trapezoidal", "simpson", "gauss_legendre"]:
        errors = [results["methods"][n][method] for n in n_list]
        # Error should generally decrease (with some oscillation for Romberg)
        assert errors[-1] < errors[0] * 0.1  # At least 10x improvement


def test_polymer_data():
    """Test polymer data availability"""
    assert "PVC" in POLYMER_DATA
    assert "PU" in POLYMER_DATA
    assert "PC" in POLYMER_DATA

    for polymer, data in POLYMER_DATA.items():
        assert "Tg" in data
        assert "T_max" in data
        assert "Ea" in data
        assert "HS" in data
